export class ApprovedM
{
  constructor
  (
    public policyId:string,
    public userName:string,
  ){}
}
