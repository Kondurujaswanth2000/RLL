import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminh',
  templateUrl: './adminh.component.html',
  styleUrls: ['./adminh.component.css']
})
export class AdminhComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
