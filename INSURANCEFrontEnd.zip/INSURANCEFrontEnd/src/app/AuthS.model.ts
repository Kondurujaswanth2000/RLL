export class AuthS
{
  userName!: string;
  password!: string;
  authenticated!: boolean
  constructor() {}
}
