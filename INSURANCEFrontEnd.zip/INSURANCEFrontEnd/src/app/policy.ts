export class Policy
{
  constructor
  (
    public policy_id: number,
    public policyName:string,
    public amount:string,
    public tenureInYears:string,
    public category:string,
 ){}
}
