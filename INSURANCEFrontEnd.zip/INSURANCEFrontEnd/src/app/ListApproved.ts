export class Approve
{
  constructor
  (
    public policyId:string,
    public userName:string,
  ){}
}
