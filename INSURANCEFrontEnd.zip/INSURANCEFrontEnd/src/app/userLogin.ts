export class UserLogin
{
  constructor
  (
    public userName:string,
    public password:string,
  ){}
}
